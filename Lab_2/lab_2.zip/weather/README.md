Lab_2: Weather Map

Component can be found in src/app/weather-map

Service can be found in src/app/service

Uses the openweathermapAPI to fetch weather data from cities that are in
the current view of googleMaps

extended from the original (now deprecated) google maps openweatherAPI tutorial

- Converted to angular 5
- added use of the in-browser navigator.geolocation to initialize map to user's current location

